var webdriverio = require('webdriverio');
var assert = require('assert');

var browserOption = "chrome"; // Can use chrome, firefox
var options = {
    desiredCapabilities: {
        browserName: browserOption // Can use chrome, firefox
    }
};

var loginEmail = "p.donglin@gmail.com";
var loginPassword = "1q2w3e4r";
var numberOfClickedImages = 0;


client = webdriverio.remote(options);

client
    .init()
    .url('https://www.dstldjeans.com')
    // Step 1. Log user in
    .waitForVisible('a[data-target="#login"]', 5000)
    .click('a[data-target="#login"]')
    .isVisible('input[ng-model="user.email"]', function(err, isVisible) {
    	assert(isVisible === true, "Email input not visible."); // outputs: false
    })
    .isVisible('input[ng-model="user.password"]', function(err, isVisible) {
        assert(isVisible === true, "Password input not visible."); // outputs: false
    })
    .setValue('input[ng-model="user.email"]', loginEmail)
    .setValue('input[ng-model="user.password"]', loginPassword)
    .click('input[value="Login"]')
    /*
     * 1. after click login, check Account link is on the navbar => $('a[href="/account"]:contains("Account")')
     * 2. Cannot check cookie. I cannot find a cookie for login status
     */
    .waitForVisible('.desktop-only a[href="/account"]', 5000)
    .isVisible('.desktop-only a[href="/account"]', function(err, isVisible) {
        assert(isVisible === true, "Account link is not visible.");
    })
   .pause(2000)
    // Step 2. Navigate to https://www.dstldjeans.com/shop/mens
    .click('.navbar a[href="/shop/mens"]') 
    // Step 3. Navigate to https://www.dstldjeans.com/shop/womens
    .click('.navbar a[href="/shop/womens"]')
    // Step 4. Navigate to https://www.dstldjeans.com/shop/womens/jeans/fit/ripped-jeans
    .pause(2000)
    .isVisible('.navbar a[ng-href="/shop/womens"] + ul.dropdown-menu')
    .moveToObject('.navbar a[ng-href="/shop/womens"]')
    .click('.navbar a[ng-href="/shop/womens"] + ul.dropdown-menu a[href="/shop/womens/jeans/fit/ripped-jeans"]', function(){
    	client.waitForExist('.img', 5000);
    	client.isExisting('.img', function(err, result){
    		assert(result === true, "Images are not visible.");
    	});

		// Step 5. Click on each of the product images, and navigate back to the above page
    	var clickImage = function () {
    		client.elements('.product-link', function(err, elementsResult){ // find 
    			client.elementIdAttribute(elementsResult.value[numberOfClickedImages].ELEMENT, "href", function(err, result){
    				client.url(result.value); // Could not scroll down. So have to use .url here.
    				client.waitForExist('.product-name', 5000, function(err, result){
    		    		assert(result === true, "Product name is not visible.");
    		    	});
    				client.pause(1000);
        			client.moveToObject('.navbar a[ng-href="/shop/womens"]');
            		client.isVisible('.navbar a[ng-href="/shop/womens"] + ul.dropdown-menu');
            		client.click('.navbar a[ng-href="/shop/womens"] + ul.dropdown-menu a[href="/shop/womens/jeans/fit/ripped-jeans"]');
            		client.pause(1000);
            		client.waitFor('.bg-img', 5000, function(){
            			numberOfClickedImages++;
            			if (numberOfClickedImages < elementsResult.value.length) {
            				client.call(clickImage);
            			}
            		});
        		});
    		});
    	}
    	clickImage();
    })
    // Step 6. Click on the first product image to navigate to that product page,
    .pause(2000)
    .elements('.product-link', function(err, elementsResult){
    	client.elementIdAttribute(elementsResult.value[0].ELEMENT, "href", function(err, result){
    		client.url(result.value); // Could not scroll down. So have to use .url here.
    		
    		// Step 7. Click on each of the Mini product images below the main image
    		var numberOfClickedMiniProducts = 1;
    		var clickMiniProduct = function () {
    			client.moveToObject('.top-container ol'); // Does not work on Chrome
        		client.elements('.top-container ol li img', function(err, elementsResult){
        			client.elementIdClick(elementsResult.value[numberOfClickedMiniProducts].ELEMENT, function(err, result){
        				client.pause(1000);
        				numberOfClickedMiniProducts++;
            			if (numberOfClickedMiniProducts < elementsResult.value.length) {
            				client.call(clickMiniProduct);
            			}
            		});
        		});
        	}
    		clickMiniProduct();
    	});
    })
    // Step 8. Select the product size 26 and 30 (Regular)
    .pause(2000)
    .click('//a[contains(text(), "26")]')
    .getAttribute('//a[contains(text(), "26")]', 'class', function(err, attr) {
    	assert(attr[0].split(" ").indexOf("active") !== -1, "Class 'active is not added.");
    })
    .click('//a[contains(text(), "30 (Regular)")]')
    .getAttribute('//a[contains(text(), "30 (Regular)")]', 'class', function(err, attr) {
    	assert(attr.split(" ").indexOf("active") !== -1, "Class 'active is not added.");
    })
    // Step 9. Click on Add to Cart
    .pause(2000)
    .click('//div[contains(text(), "Add To Cart")]')
    .moveToObject('.desktop-only .navbar a[href="/account"]') // Scroll back to top. Does not work on Chrome
    .waitForVisible('.desktop-only .navbar a[href="/checkout"]', 5000)
    .isVisible('.desktop-only .navbar a[href="/checkout"]', function(err, result){
    	assert(result === true, "Checkout link is not shown.");
    })
    
    // Step 10. Click on the checkout dropdown to go to the checkout page
    .pause(2000)
    .waitFor('.cart-open', 5000)
    .click('.desktop-only .navbar a[href="/checkout"]')
    .waitForExist('#checkout', 5000)
    .isVisible('#checkout', function(err, result){
    	assert(result === true, "Div with ID=checkout is not visible.");
    })
    .end(function(){
    	console.log("Test passed on " + browserOption);
    });

